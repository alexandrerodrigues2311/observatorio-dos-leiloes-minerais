"""Reprodução das tabelas e figuras do artigo B2. Valores monetários nominais.
Entrada: extrato analítico preservado + resultado SOPLe preservado.
O módulo coleta_anm.py permite recuperar e integrar as bases oficiais atualizadas.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import date
import csv, json, hashlib, unicodedata, statistics, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, FancyBboxPatch
from matplotlib.colors import Normalize

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'resultados'; OUT.mkdir(exist_ok=True)
BLUE='#173D64'; TEAL='#087E83'; AMBER='#C68126'; GRAY='#718096'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','axes.labelcolor':BLUE,'text.color':BLUE,'axes.edgecolor':'#CDD5DE','savefig.facecolor':'white','figure.facecolor':'white','svg.fonttype':'none'})
def fold(x):return ''.join(c for c in unicodedata.normalize('NFKD',str(x)) if not unicodedata.combining(c)).lower().strip()
def ix(s):return int(s[:4])*12+int(s[5:7])-1
def br(x,n=0):return f'{x:,.{n}f}'.replace(',','@').replace('.',',').replace('@','.')
def normsub(s):
 s=str(s).upper().strip()
 return {'MINÉRIO DE OURO':'OURO','FERRO':'MINÉRIO DE FERRO','MANGANÊS':'MINÉRIO DE MANGANÊS'}.get(s,s)
def dump(name,rows):
 if not rows:return
 with (OUT/(name+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def save(fig,name):
 fig.savefig(OUT/(name+'.png'),dpi=240,bbox_inches='tight')
 fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight')
 fig.savefig(OUT/(name+'.svg'),bbox_inches='tight');plt.close(fig)
def note(fig,s):fig.text(.02,.01,s,fontsize=8,color=GRAY,va='bottom')
def selected(r,p,m):
 if r.get('cycleWindows'):return any(w['process']==p and w['startExcluded']<m<w['endExcluded'] and m<='2026-06' for w in r['cycleWindows'])
 return r['data_referencia'][:7]<m<='2026-06'
def guides(D,p):return sorted([g for g in D['guideEvidence']['processes'].get(p,[]) if g['date']<='2026-06-30'],key=lambda g:g['date'])
def guide_ok(gs,g):
 end=g.get('explicitEnd') or g.get('estimatedEnd')
 return bool(end and g['date'][:7]<'2026-06'<end[:7] and not any((a.get('interruption') or a.get('extension')) and g['date']<=a['date']<='2026-06-30' for a in gs))
def absence(D,r):
 out=[]
 for p in r['sucessores_candidatos']:
  phase=D['enrichment']['phases'].get(p,{}).get('fase','');f=fold(phase);gs=guides(D,p);aa=[g for g in gs if g['authorization']];g=aa[-1] if aa else None
  productive=f in ['concessao de lavra','licenciamento','lavra garimpeira','permissao de lavra garimpeira']
  ts=[t['publicacao'] for t in D['enrichment']['titles'].get(p,[]) if t['publicacao']<='2026-06-30' and any(s in fold(t['documento']) for s in ['concess','licenc','lavra garimpeira'])]
  key='missing' if not phase else 'productive' if productive else ('guide' if f=='autorizacao de pesquisa' and guide_ok(gs,g) and g.get('limits') else 'review') if g else 'early'
  start=min(ts) if productive and ts else g['date'] if g and not productive else None
  out.append(dict(origem=r['origem'],processo=p,fase=phase,classe=key,inicio=start or '',fim=(g.get('explicitEnd') or g.get('estimatedEnd') or '') if g else '',meses=ix('2026-06')-ix(start) if start else '',substancia=' / '.join(x['substance'] for x in g.get('limits',[])) if g else '',uf=r['uf']))
 key=next((k for k in ['productive','guide','review','early','missing'] if any(x['classe']==k for x in out)),'missing')
 return key,out

def run():
 D=json.loads((ROOT/'dados/analitico_preservado.json').read_text(encoding='utf-8'))
 E=D['enrichment']; rows=[r for r in D['rows'] if D['businessOutcomes']['origins'][r['origem']]['state']=='continuation_to_check' and r['antes'] and r['depois']]
 assert len(rows)==6094
 allareas=D['areaScenario']['areas'];awards=len(allareas);unpaid=[a for a in allareas if a['unpaid']]
 finance=[dict(situacao='Lances vencedores',areas=awards,reais=sum(a['cents'] for a in allareas)/100),dict(situacao='Não pagamento identificado',areas=len(unpaid),reais=sum(a['cents'] for a in unpaid)/100)]
 finance.append(dict(situacao='Saldo sob premissa',areas=awards-len(unpaid),reais=finance[0]['reais']-finance[1]['reais']))
 dump('tabela_1_financeiro',finance)
 matrix=Counter((bool(r['antes']['positivo']),bool(r['depois']['positivo'])) for r in rows)
 dump('tabela_2_transicoes',[dict(antes=k[0],depois=k[1],trajetorias=v,percentual=v/len(rows)*100) for k,v in matrix.items()])
 rounds=[]
 for n in [1,2,3,4,5,8]:
  aa=[a for a in allareas if a['round']==n];rr=[r for r in rows if r['arrematacoes'][-1]['rodada']==n];uu=[a for a in aa if a['unpaid']]
  rounds.append(dict(rodada=n,arremates=len(aa),nao_pagamentos=len(uu),lances=sum(a['cents'] for a in aa)/100,nao_pagamento_reais=sum(a['cents'] for a in uu)/100,comparaveis=len(rr),com_cfem=sum(r['depois']['positivo'] for r in rr),cfem=sum(r['depois']['reais'] for r in rr)))
 dump('tabela_C2_C5_rodadas',rounds)
 regimes=[]
 for reg in ['Pesquisa','Lavra-Concessão']:
  rr=[r for r in rows if r['regime']==reg];regimes.append(dict(regime=reg,n=len(rr),com_cfem=sum(r['depois']['positivo'] for r in rr),cfem=sum(r['depois']['reais'] for r in rr)))
 social=D['socialRound6']['records'];sp=[r for r in social if r['cfem_cents']>0]
 regimes.append(dict(regime='PLG — avaliação social',n=len(social),com_cfem=len(sp),cfem=sum(r['cfem_cents'] for r in social)/100));dump('tabela_C3_regimes',regimes)
 windows=[];coverage=set(D['coverage'])
 for w in [12,24]:
  rr=[r for r in rows if not r.get('cycleWindows') and r['antes']['meses_observados']>=w and r['depois']['meses_observados']>=w and all(m in coverage for m in list(range(ix(r['data_referencia'])-w,ix(r['data_referencia'])))+list(range(ix(r['data_referencia'])+1,ix(r['data_referencia'])+w+1)))]
  vals=[0,0];payers=[0,0]
  for r in rr:
   t=ix(r['data_referencia']);vv=[sum(x[1] for x in r['mensal'] if t-w<=ix(x[0])<t)/100,sum(x[2] for x in r['mensal'] if t<ix(x[0])<=t+w)/100]
   for j in range(2):vals[j]+=vv[j];payers[j]+=vv[j]>0
  for j,side in enumerate(['antes','depois']):windows.append(dict(janela_meses=w,periodo=side,n=len(rr),com_cfem=payers[j],total=vals[j],media_mensal_por_area=vals[j]/len(rr)/w,media_anual_equivalente=vals[j]/len(rr)/w*12))
 dump('tabela_C4_janelas',windows)
 categories=Counter();alerts=[]
 for r in rows:
  if r['antes']['positivo'] or r['depois']['positivo']:continue
  k,items=absence(D,r);categories[k]+=1;alerts.extend(items)
 dump('tabela_3_potencial',[dict(classe=k,trajetorias=v) for k,v in categories.items()]);dump('alertas_por_processo',alerts)
 assert categories==Counter({'early':5743,'review':48,'guide':33,'productive':19,'missing':4}),categories
 timeline=[];admin=[]
 for r in rows:
  if len(r['arrematacoes'])!=1 or r.get('cycleWindows'):continue
  anchor=r['data_referencia'][:10];first=r.get('primeiro_depois');group='Continuidade do recolhimento' if r['antes']['positivo'] else 'Sem recolhimento anterior'
  timeline.append(dict(origem=r['origem'],grupo=group,rodada=r['arrematacoes'][0]['rodada'],referencia=anchor,primeiro_cfem=first or '',meses_ate_cfem=ix(first)-ix(anchor) if first else '',meses_observados=r['depois']['meses_observados'],cfem=r['depois']['reais']))
  requests=[];titles=[];pairs=[]
  for v in r['vinculos']:
   if not v['associacao'] or not anchor<=v['associacao'][:10]<='2026-06-30':continue
   p=v['processo'];start=max(anchor,v['associacao'][:10]);ev=E['successorEvents'].get(p,[])
   req=[e[0][:10] for e in ev if e[1] in ['100','350','700','333'] and start<=e[0][:10]<='2026-06-30']
   ts=[t['publicacao'][:10] for t in E['titles'].get(p,[]) if t['situacao']=='Outorgado' and t['publicacao'] and start<=t['publicacao'][:10]<='2026-06-30']
   if req:requests.append(min(req))
   if ts:titles.append(min(ts))
   if req and ts and min(ts)>=min(req):pairs.append((date.fromisoformat(min(ts))-date.fromisoformat(min(req))).days)
  admin.append(dict(origem=r['origem'],requerimento=min(requests) if requests else '',titulo=min(titles) if titles else '',dias_requerimento=(date.fromisoformat(min(requests))-date.fromisoformat(anchor)).days if requests else '',dias_requerimento_titulo=min(pairs) if pairs else ''))
 for r in social:
  # Social: início da associação e CFEM posterior à associação de cada sucessor.
  links={x['process']:x['date'] for x in r['links'] if x['date']}
  if not links:continue
  anchor=min(links.values());mm=sorted(p['month'] for p in r['profiles'] if p['cents']>0 and p['process'] in links and links[p['process']][:7]<p['month']<='2026-06')
  timeline.append(dict(origem=r['origin'],grupo='Avaliação social',rodada=6,referencia=anchor,primeiro_cfem=mm[0] if mm else '',meses_ate_cfem=ix(mm[0])-ix(anchor) if mm else '',meses_observados=ix('2026-06')-ix(anchor),cfem=r['cfem_cents']/100))
 dump('tempos_primeiro_cfem',timeline);dump('tempos_administrativos',admin)
 times=[]
 for g in ['Sem recolhimento anterior','Continuidade do recolhimento','Avaliação social']:
  rr=[r for r in timeline if r['grupo']==g];vals=[r['meses_ate_cfem'] for r in rr if r['primeiro_cfem']]
  times.append(dict(grupo=g,acompanhaveis=len(rr),com_cfem=len(vals),mediana=float(np.median(vals)),q1=float(np.percentile(vals,25)),q3=float(np.percentile(vals,75)),min=min(vals),max=max(vals)))
 dump('resumo_tempos',times)
 # Extratos territoriais: local de extração declarado na CFEM, não endereço do titular.
 territory=defaultdict(int);quantities=defaultdict(float);fiscal_seen=set();production_seen=set();records=[]
 for r in rows:
  for p in r['sucessores_candidatos']:
   for j,x in enumerate(E['profiles'].get(p,[])):
    if not selected(r,p,x[0]):continue
    key=(p,j)
    if key in fiscal_seen:raise AssertionError('Registro fiscal atribuído a mais de uma trajetória: '+str(key))
    fiscal_seen.add(key);sub=normsub(x[3]);territory[('Leilão',x[4],x[5],sub)]+=x[6]
    records.append(dict(grupo='Leilão',origem=r['origem'],processo=p,mes=x[0],uf=x[4],municipio=x[5],substancia=sub,centavos=x[6]))
   for j,x in enumerate(E['production'].get(p,[])):
    if not selected(r,p,x[0]):continue
    if (p,j) in production_seen:raise AssertionError('Quantidade duplicada')
    production_seen.add((p,j));sub=normsub(x[1]);u=x[2].strip().lower().replace('³','3');q=x[5]
    if u=='kg':q/=1000;u='t'
    quantities[('Leilão',x[3],x[4],sub,u)]+=q
 for r in social:
  for x in r['profiles']:
   territory[('Avaliação social',x['uf'],x['city'],normsub(x['substance']))]+=x['cents']
   records.append(dict(grupo='Avaliação social',origem=r['origin'],processo=x['process'],mes=x['month'],uf=x['uf'],municipio=x['city'],substancia=normsub(x['substance']),centavos=x['cents']))
   q=float(x['quantity'].replace('.','').replace(',','.'));u=x['unit'].strip().lower().replace('³','3')
   if u=='kg':q/=1000;u='t'
   quantities[('Avaliação social',x['uf'],x['city'],normsub(x['substance']),u)]+=q
 tt=[dict(grupo=k[0],uf=k[1],municipio=k[2],substancia=k[3],cfem=v/100) for k,v in territory.items()]
 qq=[dict(grupo=k[0],uf=k[1],municipio=k[2],substancia=k[3],unidade=k[4],quantidade=v) for k,v in quantities.items()]
 dump('territorio_cfem',tt);dump('comercializacao_declarada',qq);dump('cfem_posterior_rastreavel',records)
 sum_profiles=sum(x['cfem'] for x in tt)
 assert abs(sum_profiles-6526131.24)<.02,(sum_profiles,'CFEM territorial não reconcilia')
 terminal=Counter();groups=defaultdict(set)
 with (ROOT/'dados/ResultadoRodadaDisponibilidade.csv').open(encoding='utf-8-sig') as f:
  for x in csv.DictReader(f,delimiter=';'):
   if x['Rodada']=='7':continue
   groups[(x['Rodada'],x['NumeroArea'],x['ProcessoMinerario'])].add(x['Situacao'])
 for ss in groups.values():
  ss=ss-{'Aguardando Leilão'};terminal[next(iter(ss)) if len(ss)==1 else 'Conflito']+=1
 assert sum(terminal.values())==21449
 dump('tabela_C1_destinacao',[dict(situacao=k,n=v) for k,v in terminal.items()])
 metrics=dict(financeiro=finance,transicoes={str(k):v for k,v in matrix.items()},tempos=times,regimes=regimes,potencial=dict(categories),cfem_total=sum_profiles,administrativo=dict(com_requerimento=sum(bool(x['requerimento']) for x in admin),com_titulo=sum(bool(x['titulo']) for x in admin),mediana_requerimento=statistics.median(x['dias_requerimento'] for x in admin if x['dias_requerimento']!=''),mediana_titulo=statistics.median(x['dias_requerimento_titulo'] for x in admin if x['dias_requerimento_titulo']!='')),origem_dados_sha256=hashlib.sha256((ROOT/'dados/analitico_preservado.json').read_bytes()).hexdigest())
 (OUT/'metricas_b2.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
 figures(D,rows,rounds,timeline,times,alerts,territory,terminal)
 print(json.dumps(metrics,ensure_ascii=False,indent=2));return metrics

def figures(D,rows,rounds,timeline,times,alerts,territory,terminal):
 # Fluxo em trilhas: não finge que unidades e subconjuntos heterogêneos são um Sankey conservativo.
 fig,ax=plt.subplots(figsize=(10.5,5.2));ax.set(xlim=(0,10),ylim=(0,5));ax.axis('off')
 def box(x,y,w,h,text,c=BLUE):
  ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.07',fc=c,ec='none'));ax.text(x+w/2,y+h/2,text,ha='center',va='center',color='white',fontsize=10)
 def arrow(x,y,xx,yy):ax.annotate('',(xx,yy),(x,y),arrowprops=dict(arrowstyle='->',color=GRAY,lw=1.5))
 box(.1,3.6,2.1,.85,'21.449 áreas listadas\n6 rodadas com arremates')
 box(2.85,3.6,2,.85,'7.528 arrematações\n7.526 origens distintas');arrow(2.3,4,2.75,4)
 box(5.55,4,2,.75,'1.272 com não\npagamento identificado',AMBER);arrow(4.95,4.15,5.45,4.35)
 box(5.55,2.9,2,.75,'6.256 sem registro\nde não pagamento',TEAL);arrow(4.95,3.85,5.45,3.3)
 ax.text(7.85,3.25,'Saldo sob premissa\nNão certifica quitação',fontsize=9,color=GRAY,va='center')
 box(.1,2.2,2.1,.85,'4.583 conquistadas\nsem disputa financeira',GRAY);arrow(1.15,3.5,1.15,3.15)
 ax.text(.1,1.55,'9.063 livres · 183 suspensas\n91 retiradas · 1 conflito',fontsize=8.5,color=GRAY)
 box(3,1.4,2.25,.8,'6.094 trajetórias\nfiscais comparáveis',BLUE)
 box(5.9,1.4,2.2,.8,'101 com CFEM posterior\nR$ 4,12 milhões',TEAL);arrow(5.35,1.8,5.8,1.8)
 ax.text(3,2.5,'Reconstrução dos processos sucessores',fontsize=9,color=GRAY)
 box(.1,.15,2.1,.85,'420 áreas sociais\n171 requeridas',GRAY)
 box(3,.15,2.25,.85,'170 com associação\n233 processos associados',BLUE);arrow(2.3,.58,2.9,.58)
 box(5.9,.15,2.2,.85,'13 com CFEM posterior\nR$ 2,40 milhões',TEAL);arrow(5.35,.58,5.8,.58)
 ax.text(9.05,1.1,'114 áreas\nR$ 6,53 mi',fontsize=11,fontweight='bold',ha='center')
 note(fig,'Trilhas administrativas e fiscais têm unidades distintas. Setas representam relações, não equivalência entre contagens.');fig.subplots_adjust(bottom=.12);save(fig,'figura_2_trajetorias')
 fig,axs=plt.subplots(1,2,figsize=(10.5,4.3),sharey=True);y=np.arange(len(rounds))
 for ax,field,den,title,c in [(axs[0],'nao_pagamentos','arremates','A · Participação nas arrematações',BLUE),(axs[1],'nao_pagamento_reais','lances','B · Participação no valor dos lances',AMBER)]:
  vals=[r[field]/r[den]*100 for r in rounds];ax.barh(y,vals,color=c,height=.57);ax.set_xlim(0,65);ax.set_yticks(y,[str(r['rodada'])+'ª rodada' for r in rounds]);ax.invert_yaxis();ax.set_title(title,loc='left',fontsize=11,pad=15);ax.set_xlabel('Não pagamento identificado (%)');ax.set_xticks([0,20,40,60]);ax.xaxis.grid(True,alpha=.16);ax.set_axisbelow(True)
  for i,v in enumerate(vals):ax.text(v+1,i,br(v,1)+'%',va='center',fontsize=10)
 note(fig,'Totais: 16,90% das arrematações e 26,78% dos lances. Valores dependem da identificação administrativa, não de conciliação bancária.');fig.subplots_adjust(bottom=.22,wspace=.18);save(fig,'figura_3_nao_pagamento')
 horizons=[6,12,18,24,36,48,60];rrs=[1,2,3,4,5,8];mat=np.full((6,7),np.nan);labels={};heat=[]
 for i,n in enumerate(rrs):
  base=[r for r in timeline if r['rodada']==n]
  for j,h in enumerate(horizons):
   eligible=[r for r in base if r['meses_observados']>=h];payers=sum(r['primeiro_cfem']!='' and r['meses_ate_cfem']<=h for r in eligible)
   if eligible:mat[i,j]=100*payers/len(eligible);labels[i,j]=br(mat[i,j],1)+'%\nn='+br(len(eligible));heat.append(dict(rodada=n,meses=h,elegiveis=len(eligible),com_cfem_ate_h=payers,percentual=mat[i,j]))
 dump('maturidade_rodadas',heat)
 fig,ax=plt.subplots(figsize=(10.5,4.5));cm=plt.get_cmap('YlGnBu').copy();cm.set_bad('#E4E8EC');im=ax.imshow(mat,cmap=cm,vmin=0,vmax=5,aspect='auto')
 ax.set_xticks(range(7),[str(x) for x in horizons]);ax.set_yticks(range(6),[str(x)+'ª rodada' for x in rrs]);ax.set_xlabel('Meses completos desde a referência da homologação')
 for i in range(6):
  for j in range(7):ax.text(j,i,labels.get((i,j),'Não observado'),ha='center',va='center',fontsize=8,color='white' if np.isfinite(mat[i,j]) and mat[i,j]>3.2 else BLUE)
 fig.colorbar(im,ax=ax,pad=.02,label='Áreas com algum recolhimento até o mês (%)')
 note(fig,'Cada célula usa somente trajetórias com tempo suficiente para aquele horizonte. Cinza não é zero. Excluídos ciclos recompostos.');fig.subplots_adjust(bottom=.2);save(fig,'figura_4_maturidade')
 fig,ax=plt.subplots(figsize=(10.5,3.6));colors=[TEAL,BLUE,AMBER]
 for i,t in enumerate(times):
  v=[r['meses_ate_cfem'] for r in timeline if r['grupo']==t['grupo'] and r['primeiro_cfem']];jitter=np.random.default_rng(42).uniform(-.12,.12,len(v));ax.scatter(v,i+jitter,s=17,alpha=.35,color=colors[i]);ax.plot([t['q1'],t['q3']],[i,i],lw=7,color=colors[i]);ax.scatter([t['mediana']],[i],s=70,color='white',edgecolor=colors[i],lw=2,zorder=5);ax.text(65,i,f"Mediana {br(t['mediana'],1).removesuffix(',0')} meses\nn = {t['com_cfem']}",va='center',fontsize=9)
 ax.set_yticks(range(3),['Sem CFEM anterior','Já recolhiam antes','Avaliação social']);ax.invert_yaxis();ax.set(xlim=(0,83),xlabel='Meses até o primeiro recolhimento observado depois do marco');ax.set_xticks(range(0,61,12));ax.xaxis.grid(True,alpha=.17);ax.set_axisbelow(True)
 note(fig,'Pontos: casos com recolhimento. Barra: intervalo entre quartis. Social: marco da associação; demais: homologação.\nTempos dos casos que chegaram ao recolhimento, não estimativas de espera de todas as áreas.');fig.subplots_adjust(left=.21,bottom=.27);save(fig,'figura_5_tempos')
 # Localização das origens em SIGMINE; não usar centroide como local exato da extração.
 fig,axs=plt.subplots(1,2,figsize=(10.5,5.5))
 def base(ax):
  for f in D['brazil']['features']:
   geo=f['geometry'];polys=[geo['coordinates']] if geo['type']=='Polygon' else geo['coordinates']
   for poly in polys:ax.add_patch(Polygon(poly[0],fc='#F1F4F6',ec='#ADB9C6',lw=.45))
  ax.set(xlim=(-75,-33),ylim=(-35,7));ax.set_aspect(1.05);ax.axis('off')
 pts=[r for r in rows if r['depois']['positivo']];located=0
 for ax in axs:base(ax)
 for r in rows:
  co=D['coordinates'].get(r['origem'].replace('.',''))
  if co:axs[0].scatter(*co,s=2,color=BLUE,alpha=.17,lw=0)
 for r in pts:
  co=D['coordinates'].get(r['origem'].replace('.',''))
  if co:located+=1;axs[0].scatter(*co,s=19,color=TEAL,edgecolor='white',lw=.3,zorder=4)
 axs[0].set_title('A · Trajetórias vinculadas a leilão',loc='left',fontsize=11)
 axs[0].scatter([],[],s=12,color=BLUE,label='Trajetórias acompanhadas');axs[0].scatter([],[],s=24,color=TEAL,label=f'Com CFEM: {located} localizadas / {len(pts)}');axs[0].legend(loc='lower left',fontsize=8,frameon=False)
 uf=Counter()
 for (g,s,city,sub),v in territory.items():uf[s]+=v/100
 maxval=max(uf.values());cm=plt.get_cmap('YlGnBu');norm=Normalize(0,maxval/1e6)
 for f in D['brazil']['features']:
  sig=f['properties']['sigla'];geo=f['geometry'];polys=[geo['coordinates']] if geo['type']=='Polygon' else geo['coordinates'];val=uf.get(sig,0)/1e6
  for poly in polys:axs[1].add_patch(Polygon(poly[0],fc=cm(norm(val)) if val else '#F1F4F6',ec='#8294A5',lw=.5))
  if val:
   poly=max(polys,key=lambda p:len(p[0]));xy=np.array(poly[0]).mean(axis=0);axs[1].text(*xy,sig,fontsize=8,ha='center',color='white' if val>maxval/1e6*.6 else BLUE)
 axs[1].set_title('B · UF de extração declarada na CFEM',loc='left',fontsize=11);fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cm),ax=axs[1],fraction=.04,pad=.01,label='CFEM posterior (R$ milhões)')
 note(fig,'A: posições de referência das áreas de origem; sobreposições possíveis. B: leilão + avaliação social; extração declarada, não repasse.\nMalha estadual preservada do IBGE e posições SIGMINE; coordenadas geográficas. Base fiscal até junho/2026.');fig.subplots_adjust(bottom=.15,wspace=.03);save(fig,'figura_D1_mapas')
 dump('cfem_por_uf',[dict(uf=k,cfem=v) for k,v in uf.most_common()])
 # Potencial é indicador cadastral; a linha não presume operação contínua.
 aa=sorted([x for x in alerts if x['classe'] in ['guide','productive'] and x['inicio'] and x['meses']>=0],key=lambda x:x['meses'],reverse=True)[:12]
 fig,ax=plt.subplots(figsize=(10.5,5.8));y=np.arange(len(aa))
 for i,x in enumerate(aa):
  c=AMBER if x['classe']=='guide' else BLUE;ax.plot([-x['meses'],0],[i,i],color=c,lw=4,alpha=.7);ax.scatter([-x['meses']],[i],color=c,s=35);ax.text(1,i,f"{x['meses']} meses",va='center',fontsize=9)
 ax.set_yticks(y,[x['processo'] for x in aa]);ax.invert_yaxis();ax.set_xlabel('Meses desde o ato documentado até junho/2026 (marco zero)');ax.axvline(0,color=BLUE,lw=1);ax.set_xlim(-max(x['meses'] for x in aa)-3,12);ax.xaxis.grid(True,alpha=.15)
 ax.plot([],[],color=BLUE,lw=4,label='Título em regime com potencial');ax.plot([],[],color=AMBER,lw=4,label='Pesquisa com guia no prazo estimado');ax.legend(loc='lower left',bbox_to_anchor=(0,1.01),frameon=False,fontsize=8,ncol=2)
 note(fig,'12 sucessores com maior intervalo entre os atos recuperados e o corte. Não é duração de dívida nem comprovação de operação.\nFase cadastral em setembro/2026; conferir vigência e condições do ato até junho/2026. Casos sem data não são ordenados por tempo.');fig.subplots_adjust(left=.2,bottom=.2);save(fig,'figura_D2_prioridades')
 dump('prioridades_figura_D2',aa)

if __name__=='__main__':run()
