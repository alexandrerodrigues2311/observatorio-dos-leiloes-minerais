"""Conexão direta às bases abertas da ANM e auditoria da coorte do artigo.

Não sobrepõe o extrato preservado. Atualizações cadastrais e novos ciclos são
exportados para conferência antes de alterar a coorte publicada. Não há senha.
"""
from pathlib import Path
import urllib.request, csv, json, zipfile, io, hashlib, re, time
from collections import defaultdict, Counter, deque
from decimal import Decimal
from datetime import datetime, timezone

BASE='https://dadosabertos.anm.gov.br/'
SOURCES={
 'ResultadoRodadaDisponibilidade.csv':'SOPLE/ResultadoRodadaDisponibilidade.csv',
 'ResultadoAvaliacaoSocial.csv':'SOPLE/ResultadoAvaliacaoSocial.csv',
 'EstoqueAreas.csv':'SOPLE/EstoqueAreas.csv',
 'scm.zip':'SCM/microdados/microdados-scm.zip',
 **{f'CFEM_Arrecadacao_{a}_{b}.csv':f'CFEM/CFEM_Arrecadacao_{a}_{b}.csv' for a,b in [(2002,2006),(2007,2011),(2012,2016),(2017,2021),(2022,2026)]}}
EXPECTED={
 'ResultadoRodadaDisponibilidade.csv':{'Rodada','NumeroArea','ProcessoMinerario','Situacao','ValorLanceVencedorReais'},
 'ResultadoAvaliacaoSocial.csv':{'Rodada','NumeroArea','ProcessoMinerario','Situacao'},
 'EstoqueAreas.csv':{'ProcessoMinerario','SituacaoEstoque'},
 'CFEM':{'Ano','Mês','Processo','AnoDoProcesso','Substância','UF','Município','QuantidadeComercializada','UnidadeDeMedida','ValorRecolhido'}}
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def proc(s):
 s=str(s).strip().replace('.','')
 if '/' not in s:return ''
 a,b=s.split('/',1)
 if not a.isdigit() or not b[:4].isdigit():return ''
 a=a.zfill(6);return a[:3]+'.'+a[3:]+'/'+b[:4]
def cents(s):return int((Decimal(str(s).strip().replace('.','').replace(',','.'))*100).quantize(Decimal('1')))
def qty(s):return Decimal(str(s).strip().replace('.','').replace(',','.'))
def download(root,names=None):
 root=Path(root);root.mkdir(exist_ok=True,parents=True);manifest=[]
 for name in names or SOURCES:
  url=BASE+SOURCES[name];dest=root/name;meta={'arquivo':name,'url':url,'consulta_utc':datetime.now(timezone.utc).isoformat()}
  # Cache só é reutilizado se o servidor fornece ETag ou Last-Modified coincidente.
  req=urllib.request.Request(url,method='HEAD',headers={'User-Agent':'ObservatorioLeiloesB2/1.0'})
  with urllib.request.urlopen(req,timeout=120) as r:meta.update(etag=r.headers.get('ETag'),last_modified=r.headers.get('Last-Modified'),bytes=int(r.headers.get('Content-Length') or 0))
  oldfile=root/(name+'.metadata.json');old=json.loads(oldfile.read_text()) if oldfile.exists() else {}
  valid=dest.exists() and old.get('sha256')==digest(dest) and bool(meta['etag'] or meta['last_modified']) and all(meta[k]==old.get(k) for k in ['etag','last_modified','bytes'])
  if not valid:
   temp=root/(name+'.part')
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ObservatorioLeiloesB2/1.0'}),timeout=240) as r,temp.open('wb') as f:
    while True:
     b=r.read(2**20)
     if not b:break
     f.write(b)
   if meta['bytes'] and temp.stat().st_size!=meta['bytes']:raise ValueError('Download incompleto: '+name)
   temp.replace(dest)
  meta['sha256']=digest(dest);meta['cache_reutilizado']=valid
  oldfile.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8');manifest.append(meta)
  print(name, dest.stat().st_size,'bytes',flush=True)
 (root/'manifesto_coleta.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
 return manifest
def source_rows(p):
 cf=Path(p).name.startswith('CFEM_');enc='cp1252' if cf else 'utf-8-sig';delimiter=',' if cf else ';'
 with Path(p).open(encoding=enc,newline='') as f:
  r=csv.DictReader(f,delimiter=delimiter);need=EXPECTED['CFEM'] if cf else EXPECTED.get(Path(p).name,set())
  if not need.issubset(r.fieldnames or []):raise ValueError('Esquema mudou em '+str(p))
  for n,x in enumerate(r,2):
   if None in x or any(v is None for v in x.values()):raise ValueError(f'Linha malformada {p}:{n}')
   yield x
def scm_rows(z,name):
 matches=[n for n in z.namelist() if n.replace('\\','/').split('/')[-1].lower()==(name+'.txt').lower()]
 if len(matches)!=1:raise ValueError('Arquivo SCM ausente ou ambíguo: '+name)
 path=matches[0]
 with io.TextIOWrapper(z.open(path),encoding='cp1252',newline='') as f:
  for n,r in enumerate(csv.DictReader(f,delimiter=';'),2):
   if None in r or any(v is None for v in r.values()):
    # Não atribuir campos deslocados a eventos; guardar a anomalia no diagnóstico.
    yield {'_erro':f'{name}:{n}'}
   else:yield r
def output(root,name,records):
 records=list(records)
 if not records:return
 with (root/(name+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
def integrate(cache,snapshot,out,cutoff='2026-06'):
 cache=Path(cache);out=Path(out);out.mkdir(exist_ok=True,parents=True);D=json.loads(Path(snapshot).read_text(encoding='utf-8'))
 # Coorte publicada preservada: todos os vínculos podem ser auditados no SCM atual.
 origins={r['origem']:r for r in D['rows']};social={r['origin']:r for r in D['socialRound6']['records']};areas=[]
 for r in source_rows(cache/'ResultadoRodadaDisponibilidade.csv'):
  if r['Situacao']=='Arrematada':areas.append(dict(rodada=int(r['Rodada']),area=r['NumeroArea'],origem=proc(r['ProcessoMinerario']),centavos=cents(r['ValorLanceVencedorReais'])))
 areas=list({(a['rodada'],a['area'],a['origem']):a for a in areas}.values());output(out,'arremates_atualizados',areas)
 stock=Counter(r['SituacaoEstoque'] for r in source_rows(cache/'EstoqueAreas.csv'));output(out,'estoque_atual',[dict(situacao=k,registros=v) for k,v in stock.items()])
 latest_social=[dict(rodada=r['Rodada'],area=r['NumeroArea'],origem=proc(r['ProcessoMinerario']),situacao=r['Situacao']) for r in source_rows(cache/'ResultadoAvaliacaoSocial.csv')];output(out,'avaliacao_social_atual',latest_social)
 graph=defaultdict(list);errors=[];links=[]
 with zipfile.ZipFile(cache/'scm.zip') as z:
  if z.testzip() is not None:raise ValueError('ZIP do SCM inválido')
  for r in scm_rows(z,'ProcessoAssociacao'):
   if '_erro' in r:errors.append(r);continue
   if r['IDTipoAssociacao']!='8':continue
   a,b=proc(r['DSProcesso']),proc(r['DSProcessoAssociado'])
   if a and b and a!=b:graph[a].append(dict(origem=a,associado=b,data=r['DTAssociacao'],fim=r['DTDesassociacao']))
  visited=set(origins)|set(social);q=deque(visited)
  while q:
   a=q.popleft()
   for l in graph.get(a,[]):
    links.append(l);b=l['associado']
    if b not in visited:visited.add(b);q.append(b)
  # Segue o sentido original → associado; não troca predecessores por sucessores.
  phase_names={r['IDFaseProcesso']:r['DSFaseProcesso'] for r in scm_rows(z,'FaseProcesso') if '_erro' not in r}
  phases=[];events=[];titles=[]
  for r in scm_rows(z,'Processo'):
   if '_erro' in r:errors.append(r);continue
   if proc(r['DSProcesso']) in visited:phases.append(dict(processo=proc(r['DSProcesso']),fase=phase_names.get(r['IDFaseProcesso'],r['IDFaseProcesso']),ativo=r['BTAtivo'],protocolo=r['DTProtocolo']))
  for r in scm_rows(z,'ProcessoEvento'):
   if '_erro' in r:errors.append(r);continue
   if proc(r['DSProcesso']) in visited and r['DTEvento'][:7]<=cutoff:events.append(dict(processo=proc(r['DSProcesso']),evento=r['IDEvento'],data=r['DTEvento'],observacao=r['OBEvento'],publicacao=r['DSPublicacaoDOU']))
  for r in scm_rows(z,'ProcessoTitulo'):
   if '_erro' in r:errors.append(r);continue
   if proc(r['DSProcesso']) in visited:titles.append(dict(processo=proc(r['DSProcesso']),documento=r['IDDocumentoLegal'],tipo=r['IDTipoDocumentoLegal'],situacao=r['IDSituacaoDocumentoLegal'],publicacao=r['DTPublicacao'],vencimento=r['DTVencimento']))
 output(out,'associacoes_direcionais',links);output(out,'fases_atuais',phases);output(out,'eventos_ate_corte',events);output(out,'titulos_atuais',titles);output(out,'linhas_scm_nao_interpretadas',errors)
 # Índice das janelas adjudicadas. Mudanças cadastrais geram conferência, não decisões silenciosas.
 windows=defaultdict(list)
 for r in origins.values():
  if D['businessOutcomes']['origins'][r['origem']]['state']!='continuation_to_check' or not r['depois']:continue
  windows[r['origem']].append((r['origem'],'antes','Leilão',r['inicio_observacao'],r['data_referencia'][:7],False))
  if r.get('cycleWindows'):
   for w in r['cycleWindows']:windows[w['process']].append((r['origem'],'depois','Leilão',w['startExcluded'],min(w['endExcluded'],'2026-07'),True))
  else:
   for p in r['sucessores_candidatos']:windows[p].append((r['origem'],'depois','Leilão',r['data_referencia'][:7],'2026-07',True))
 for r in social.values():
  for l in r['links']:windows[l['process']].append((r['origin'],'depois','Avaliação social',l['date'][:7],'2026-07',True))
 monthly=defaultdict(int);territory=defaultdict(int);quantity=defaultdict(Decimal);fiscal_rows=0;ambiguous=[];coverage=set();same_lines=Counter()
 for name in SOURCES:
  if not name.startswith('CFEM_'):continue
  for j,r in enumerate(source_rows(cache/name),2):
   m=f"{int(r['Ano']):04d}-{int(r['Mês']):02d}"
   if not '2002-01'<=m<=cutoff:continue
   coverage.add(m);p=proc(r['Processo']+'/'+r['AnoDoProcesso'])
   if p not in visited and p not in windows:continue
   matches=[w for w in windows.get(p,[]) if (w[3]<m if w[5] else w[3]<=m) and m<w[4]]
   unique={(w[0],w[1],w[2]) for w in matches}
   if len(unique)>1:ambiguous.append(dict(arquivo=name,linha=j,processo=p,mes=m,vinculos=str(sorted(unique))));continue
   if not unique:continue
   origin,side,group=next(iter(unique));v=cents(r['ValorRecolhido']);monthly[(origin,side,group,m)]+=v;fiscal_rows+=1
   # Linhas idênticas são auditadas, não removidas sem identificador do pagamento.
   fp=hashlib.sha256(json.dumps(r,sort_keys=True).encode()).hexdigest();same_lines[fp]+=1
   if side=='depois':
    sub=r['Substância'].upper().strip();sub={'MINÉRIO DE OURO':'OURO','FERRO':'MINÉRIO DE FERRO','MANGANÊS':'MINÉRIO DE MANGANÊS'}.get(sub,sub)
    key=(group,r['UF'],r['Município'],sub);territory[key]+=v
    u=r['UnidadeDeMedida'].strip().lower().replace('³','3');q=qty(r['QuantidadeComercializada'])
    if u=='kg':q/=1000;u='t'
    quantity[key+(u,)]+=q
 output(out,'cfem_mensal_recalculada',[dict(origem=k[0],periodo=k[1],grupo=k[2],mes=k[3],centavos=v) for k,v in monthly.items()])
 output(out,'territorios_recalculados',[dict(grupo=k[0],uf=k[1],municipio=k[2],substancia=k[3],centavos=v) for k,v in territory.items()])
 output(out,'quantidades_recalculadas',[dict(grupo=k[0],uf=k[1],municipio=k[2],substancia=k[3],unidade=k[4],quantidade=str(v)) for k,v in quantity.items()]);output(out,'cfem_associacao_ambigua',ambiguous)
 explicit={(l['origem'],l['associado'],l['data'][:10]) for l in links};frozen={(r['origem'],v['processo'],v['associacao'][:10]) for r in origins.values() for v in r['vinculos']}
 changes=[dict(origem=k[0],associado=k[1],data=k[2],tipo='adicional à seleção de vínculos preservada') for k in sorted(explicit-frozen)]+[dict(origem=k[0],associado=k[1],data=k[2],tipo='preservado não localizado no SCM atual') for k in sorted(frozen-explicit)]
 output(out,'vinculos_a_conferir',changes)
 eventnon=[e for e in events if e['evento']=='2464'];output(out,'nao_pagamento_evento_2464',eventnon)
 reference={('Leilão','antes'):240157016,('Leilão','depois'):412312839,('Avaliação social','depois'):240300285};actual=Counter()
 for (origin,side,group,m),v in monthly.items():actual[group,side]+=v
 comparisons=[dict(grupo=g,periodo=s,publicado_centavos=v,recalculado_centavos=actual[g,s],diferenca_centavos=actual[g,s]-v) for (g,s),v in reference.items()];output(out,'reconciliacao_publicado_atual',comparisons)
 report=dict(corte=cutoff,arremates_atual=len(areas),novas_rodadas=sorted({a['rodada'] for a in areas}-{1,2,3,4,5,8}),associacoes_recuperadas=len(links),vinculos_fora_selecao_preservada=len(changes),linhas_scm_malformadas=len(errors),registros_fiscais_atribuidos=fiscal_rows,registros_fiscais_ambiguos=len(ambiguous),repeticoes_identicas=sum(v-1 for v in same_lines.values()),comparacoes=comparisons,observacao='A atualização fiscal usa as janelas da coorte publicada. Vínculos adicionais da rede completa não significam necessariamente mudança na base ao longo do tempo. A seleção desses vínculos, novos eventos ou rodadas exige conferência antes de nova publicação. Linhas idênticas não foram excluídas automaticamente.')
 (out/'relatorio_integracao.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2));return report

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--cache',default='bases_atuais');p.add_argument('--snapshot',default='dados/analitico_preservado.json');p.add_argument('--out',default='atualizacao');p.add_argument('--download',action='store_true');a=p.parse_args()
 if a.download:download(a.cache)
 integrate(a.cache,a.snapshot,a.out)
